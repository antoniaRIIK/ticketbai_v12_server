Para poder visualizar un archivo BOE, hay que:

#. Entrar en *Facturación > Configuración > AEAT > Configuración de exportación a BOE*.
#. Entrar en el detalle de la configuración de exportación principal para
   el modelo.
#. Pulsar en el smart-button "Comparar archivo".
#. Seleccionar el archivo correspondiente y pulsar en "Comparar".
#. Aparecerá una ventana con cada una de las líneas de exportación, la cadena
   correspondiente a dicha línea, y si es un importe numérico, su cifra
   asociada.

Para importar el certificado, hay que:

#. Entrar en *Facturación > Configuración > AEAT > Certificados*
#. Crear uno nuevo. Rellenas los datos del formulurio y subir el archivo p12
#. Pulsar obtener claves e introducir la contraseña del certificado
